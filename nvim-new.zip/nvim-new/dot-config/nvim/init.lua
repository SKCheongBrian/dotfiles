require("vim._core.ui2").enable({})

require("options")
require("keymaps")
require("commands")
require("pack")
require("treesitter")

-- vim.cmd.colorscheme("rose-pine")
